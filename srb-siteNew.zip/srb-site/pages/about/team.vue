<template>
  <div class="text-box">
    <div class="text-content" id="text-content">
      <h1 class="title">团队风采</h1>
      <ul class="mt20 r-list">
        <li class="clearfix">
          <a href="">
            <img src="~/assets/images/team.jpg" width="300" height="171" />
          </a>
          <div class="record">
            <h5>
              <a href="#">服务民生</a>
            </h5>
            <p class="text">
              设立公益书友会，斥资购买图书并向市民免费开放，这也和2020年政府工作报告提出要“倡导全民阅读
              ，建设书香社会”的号召不谋而合。公益书友会将是一个交流互动的乐园，书友会将不定期举办多种活动，发挥石狮首家互联网金融公司的所长，帮助市民了解金融法规、投资理财等相关知识，为发展普惠金融做出自己的贡献。
            </p>
            <p class="time">活动时间：2020年6月</p>
          </div>
        </li>
        <li class="clearfix">
          <a href="">
            <img src="~/assets/images/team2.jpg" width="300" height="171" />
          </a>
          <div class="record">
            <h5>
              <a href="#">服务民生</a>
            </h5>
            <p class="text">
              设立公益书友会，斥资购买图书并向市民免费开放，这也和2020年政府工作报告提出要“倡导全民阅读
              ，建设书香社会”的号召不谋而合。公益书友会将是一个交流互动的乐园，书友会将不定期举办多种活动，发挥石狮首家互联网金融公司的所长，帮助市民了解金融法规、投资理财等相关知识，为发展普惠金融做出自己的贡献。
            </p>
            <p class="time">活动时间：2020年6月</p>
          </div>
        </li>
        <li class="clearfix">
          <a href="">
            <img src="~/assets/images/team3.jpg" width="300" height="171" />
          </a>
          <div class="record">
            <h5>
              <a href="#">服务民生</a>
            </h5>
            <p class="text">
              设立公益书友会，斥资购买图书并向市民免费开放，这也和2020年政府工作报告提出要“倡导全民阅读
              ，建设书香社会”的号召不谋而合。公益书友会将是一个交流互动的乐园，书友会将不定期举办多种活动，发挥石狮首家互联网金融公司的所长，帮助市民了解金融法规、投资理财等相关知识，为发展普惠金融做出自己的贡献。
            </p>
            <p class="time">活动时间：2020年6月</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
