import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _79249ddc = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _16b5a726 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _58524d2d = () => interopDefault(import('..\\pages\\about\\detail.vue' /* webpackChunkName: "pages/about/detail" */))
const _3496a8de = () => interopDefault(import('..\\pages\\about\\job.vue' /* webpackChunkName: "pages/about/job" */))
const _45c94436 = () => interopDefault(import('..\\pages\\about\\leader.vue' /* webpackChunkName: "pages/about/leader" */))
const _4a6f3034 = () => interopDefault(import('..\\pages\\about\\notice.vue' /* webpackChunkName: "pages/about/notice" */))
const _68e2311c = () => interopDefault(import('..\\pages\\about\\partner.vue' /* webpackChunkName: "pages/about/partner" */))
const _15dafce4 = () => interopDefault(import('..\\pages\\about\\policy.vue' /* webpackChunkName: "pages/about/policy" */))
const _6fb9c7c6 = () => interopDefault(import('..\\pages\\about\\price.vue' /* webpackChunkName: "pages/about/price" */))
const _3960857d = () => interopDefault(import('..\\pages\\about\\profile.vue' /* webpackChunkName: "pages/about/profile" */))
const _09356090 = () => interopDefault(import('..\\pages\\about\\report.vue' /* webpackChunkName: "pages/about/report" */))
const _5f5f1b8e = () => interopDefault(import('..\\pages\\about\\team.vue' /* webpackChunkName: "pages/about/team" */))
const _6bfd8042 = () => interopDefault(import('..\\pages\\help.vue' /* webpackChunkName: "pages/help" */))
const _62841bb8 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _29e6c224 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _e9a37068 = () => interopDefault(import('..\\pages\\user.vue' /* webpackChunkName: "pages/user" */))
const _6245ef36 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _ce470ebe = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _79249ddc,
    children: [{
      path: "",
      component: _16b5a726,
      name: "about"
    }, {
      path: "detail",
      component: _58524d2d,
      name: "about-detail"
    }, {
      path: "job",
      component: _3496a8de,
      name: "about-job"
    }, {
      path: "leader",
      component: _45c94436,
      name: "about-leader"
    }, {
      path: "notice",
      component: _4a6f3034,
      name: "about-notice"
    }, {
      path: "partner",
      component: _68e2311c,
      name: "about-partner"
    }, {
      path: "policy",
      component: _15dafce4,
      name: "about-policy"
    }, {
      path: "price",
      component: _6fb9c7c6,
      name: "about-price"
    }, {
      path: "profile",
      component: _3960857d,
      name: "about-profile"
    }, {
      path: "report",
      component: _09356090,
      name: "about-report"
    }, {
      path: "team",
      component: _5f5f1b8e,
      name: "about-team"
    }]
  }, {
    path: "/help",
    component: _6bfd8042,
    name: "help"
  }, {
    path: "/login",
    component: _62841bb8,
    name: "login"
  }, {
    path: "/register",
    component: _29e6c224,
    name: "register"
  }, {
    path: "/user",
    component: _e9a37068,
    children: [{
      path: "",
      component: _6245ef36,
      name: "user"
    }]
  }, {
    path: "/",
    component: _ce470ebe,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decodeURIComponent(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
